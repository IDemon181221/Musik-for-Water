import React, { useEffect, useCallback } from 'react';
import { useTutorial } from '../context/TutorialContext';

const TutorialOverlay: React.FC = () => {
  const tutorial = useTutorial();
  
  const currentStep = tutorial.getCurrentStep();
  const currentChapter = tutorial.getCurrentChapter();

  // Find and highlight element
  const highlightElement = useCallback(() => {
    // Remove all previous highlights
    document.querySelectorAll('.tutorial-highlight').forEach(el => {
      el.classList.remove('tutorial-highlight');
    });

    if (!tutorial.highlightedElement || tutorial.highlightedElement === 'none') {
      return;
    }

    // Try multiple selectors to find the element
    const elementId = tutorial.highlightedElement;
    const selectors = [
      `#${elementId}`,
      `[data-tutorial="${elementId}"]`,
      `[id="${elementId}"]`,
      `[id*="${elementId}"]`,
      `.${elementId}`,
      // Specific selectors for common elements
      elementId.includes('region-') ? `[id="${elementId}"], [data-region-id="${elementId.replace('region-', '')}"]` : null,
      elementId.includes('dam') ? `[data-tutorial="dam"], #dam-ataturk, .dam-marker` : null,
    ].filter(Boolean);

    let element: HTMLElement | null = null;
    for (const selector of selectors) {
      try {
        element = document.querySelector(selector as string);
        if (element) {
          console.log(`Tutorial: Found element with selector "${selector}"`);
          break;
        }
      } catch {
        continue;
      }
    }

    if (element) {
      element.classList.add('tutorial-highlight');
      
      // Scroll into view if needed
      element.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
    } else {
      console.log(`Tutorial: Could not find element "${elementId}"`);
    }
  }, [tutorial.highlightedElement]);

  // Update highlight when step changes
  useEffect(() => {
    if (!tutorial.isActive || tutorial.showChapterIntro || tutorial.showBlackSwan || tutorial.showFinalScreen) {
      // Clean up highlights when not active
      document.querySelectorAll('.tutorial-highlight').forEach(el => {
        el.classList.remove('tutorial-highlight');
      });
      return;
    }

    // Initial highlight
    highlightElement();
    
    // Keep checking for element (it might appear later)
    const interval = setInterval(highlightElement, 500);
    
    return () => {
      clearInterval(interval);
      document.querySelectorAll('.tutorial-highlight').forEach(el => {
        el.classList.remove('tutorial-highlight');
      });
    };
  }, [tutorial.isActive, tutorial.showChapterIntro, tutorial.showBlackSwan, tutorial.showFinalScreen, highlightElement, tutorial.currentStep, tutorial.currentChapter]);

  // Don't render if tutorial not active or showing intros
  if (!tutorial.isActive || tutorial.showChapterIntro || tutorial.showBlackSwan || tutorial.showFinalScreen) {
    return null;
  }

  if (!currentStep || !currentChapter) return null;

  return (
    <>
      {/* Bottom instruction panel */}
      <div className="fixed bottom-0 left-0 right-0 z-50 p-4 pointer-events-none">
        <div className="max-w-4xl mx-auto pointer-events-auto">
          <div className="bg-gradient-to-r from-gray-900/95 via-gray-800/95 to-gray-900/95 backdrop-blur-lg rounded-2xl border-2 border-[#FFB74D]/50 shadow-2xl overflow-hidden">
            {/* Chapter/Step indicator */}
            <div className="bg-[#FFB74D]/20 px-6 py-2 flex items-center justify-between">
              <span className="text-[#FFB74D] font-medium text-sm">
                Глава {currentChapter.id}: {currentChapter.titleRu} — Шаг {tutorial.currentStep + 1}/{currentChapter.steps.length}
              </span>
              <span className="text-gray-400 text-sm">
                Прогресс: {tutorial.progress}%
              </span>
            </div>

            {/* Main content */}
            <div className="p-6">
              {/* Instruction title */}
              <h3 className="text-2xl font-bold text-white mb-3">
                {currentStep.instruction}
              </h3>
              
              {/* Voice text */}
              <p className="text-gray-300 text-lg mb-4 leading-relaxed">
                {currentStep.voiceText}
              </p>

              {/* Action hint */}
              {tutorial.requiredAction && (
                <div className={`p-3 rounded-lg mb-4 ${tutorial.canProceed ? 'bg-green-900/50 border border-green-500' : 'bg-yellow-900/30 border border-yellow-600/50'}`}>
                  {tutorial.canProceed ? (
                    <p className="text-green-400 flex items-center gap-2">
                      <span className="text-2xl">✓</span>
                      <span className="font-medium">Отлично! Нажмите «Далее» для продолжения</span>
                    </p>
                  ) : (
                    <p className="text-yellow-400 flex items-center gap-2">
                      <span className="text-2xl animate-pulse">👆</span>
                      <span>
                        {tutorial.requiredAction === 'click' && `Нажмите на выделенный элемент`}
                        {tutorial.requiredAction === 'select_region' && `Выберите выделенный регион в списке слева`}
                        {tutorial.requiredAction === 'open_panel' && `Откройте указанную панель`}
                        {tutorial.requiredAction === 'launch_initiative' && `Активируйте инициативу`}
                        {tutorial.requiredAction === 'any_click' && `Нажмите на выделенный элемент или «Далее»`}
                        {tutorial.requiredAction === 'advance_time' && `Установите скорость игры и дождитесь нужной даты`}
                        {tutorial.requiredAction === 'change_dam' && `Измените режим работы плотины`}
                        {tutorial.requiredAction === 'wait' && `Подождите...`}
                      </span>
                    </p>
                  )}
                </div>
              )}

              {/* Buttons */}
              <div className="flex items-center justify-between">
                <button
                  onClick={tutorial.toggleQA}
                  className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-gray-300 transition-colors flex items-center gap-2"
                >
                  <span>❓</span>
                  Вопросы и ответы
                </button>

                <div className="flex items-center gap-3">
                  {tutorial.currentStep > 0 && (
                    <button
                      onClick={tutorial.previousStep}
                      className="px-5 py-2.5 bg-gray-700 hover:bg-gray-600 rounded-lg text-white transition-colors"
                    >
                      ← Назад
                    </button>
                  )}
                  
                  <button
                    onClick={tutorial.nextStep}
                    disabled={!tutorial.canProceed && tutorial.requiredAction !== 'any_click'}
                    className={`px-8 py-3 rounded-xl font-bold text-lg transition-all transform ${
                      tutorial.canProceed || tutorial.requiredAction === 'any_click'
                        ? 'bg-gradient-to-r from-[#FFB74D] to-yellow-500 text-black hover:scale-105 hover:shadow-lg hover:shadow-yellow-500/30'
                        : 'bg-gray-700 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    Далее →
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Global style for highlighted elements */}
      <style>{`
        .tutorial-highlight {
          position: relative !important;
          z-index: 45 !important;
          outline: 4px solid #FFB74D !important;
          outline-offset: 4px !important;
          box-shadow: 0 0 0 8px rgba(255, 183, 77, 0.3), 0 0 30px 10px rgba(255, 183, 77, 0.4) !important;
          border-radius: 8px !important;
          animation: tutorial-pulse 1.5s ease-in-out infinite !important;
        }
        
        @keyframes tutorial-pulse {
          0%, 100% {
            outline-width: 4px;
            outline-offset: 4px;
            box-shadow: 0 0 0 8px rgba(255, 183, 77, 0.3), 0 0 30px 10px rgba(255, 183, 77, 0.4);
          }
          50% {
            outline-width: 6px;
            outline-offset: 6px;
            box-shadow: 0 0 0 12px rgba(255, 183, 77, 0.4), 0 0 50px 15px rgba(255, 183, 77, 0.5);
          }
        }
        
        /* Make highlighted region cards more visible */
        .tutorial-highlight.region-card {
          transform: scale(1.02);
        }
        
        /* Ensure the highlight is visible above other elements */
        .tutorial-highlight * {
          position: relative;
        }
      `}</style>
    </>
  );
};

export default TutorialOverlay;
