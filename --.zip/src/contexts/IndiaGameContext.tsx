import React, { createContext, useContext, useReducer, useEffect, useRef, useCallback } from 'react';

// Types
export interface IndiaRegion {
  id: string;
  name: string;
  nameRu: string;
  waterStress: number;
  socialTension: number;
  trustInGovernment: number;
  militias: number;
  population: number; // millions
  isCoastal: boolean;
  terrain: 'plains' | 'mountains' | 'desert' | 'coastal';
  description: string;
}

export interface PakistanState {
  waterStress: number;
  socialTension: number;
  population: number; // millions
  waterReceived: number; // billion m³/year
  civilWarActive: boolean;
}

export interface RiverState {
  id: string;
  name: string;
  nameRu: string;
  isClosed: boolean;
  waterVolume: number; // billion m³/year that Pakistan loses when closed
  timerPenalty: number; // days lost from nuclear timer
}

export interface IndiaInitiative {
  id: string;
  name: string;
  nameRu: string;
  description: string;
  descriptionRu: string;
  category: 'civil' | 'diplomatic' | 'military' | 'unique';
  cost: number;
  duration: number; // months, 0 = instant
  effects: {
    waterStress?: number;
    socialTension?: number;
    trust?: number;
    nuclearTimer?: number;
    internationalPressure?: number;
    pakistanWaterLoss?: number;
    pakistanTension?: number;
    budget?: number;
  };
  hiddenEffects?: string;
  hiddenEffectsRu?: string;
  requirements?: {
    minBudget?: number;
    maxPressure?: number;
    minTimer?: number;
    cooldown?: number; // months since last use
  };
  isUnique?: boolean; // only in India campaign
  cooldown?: number; // current cooldown in months
  isActive?: boolean;
  monthsRemaining?: number;
  targetRegion?: string;
}

export interface NewsEvent {
  id: string;
  month: number;
  year: number;
  title: string;
  titleRu: string;
  description: string;
  descriptionRu: string;
  type: 'india' | 'pakistan' | 'international' | 'crisis';
  effects?: {
    nuclearTimer?: number;
    internationalPressure?: number;
    pakistanTension?: number;
  };
}

export type Difficulty = 'nobel' | 'realistic' | 'hard' | 'brutal' | 'nightmare' | 'hell';

export interface IndiaGameState {
  // Time
  year: number;
  month: number;
  totalMonths: number;
  gameSpeed: number;
  isPaused: boolean;
  
  // Core stats
  budget: number;
  internationalPressure: number;
  nuclearTimer: number; // days
  timerDecayRate: number; // days per month
  
  // Regions
  regions: IndiaRegion[];
  selectedRegion: string | null;
  
  // Pakistan
  pakistan: PakistanState;
  
  // Rivers
  rivers: RiverState[];
  
  // Initiatives
  initiatives: IndiaInitiative[];
  activeInitiatives: IndiaInitiative[];
  
  // Events
  events: NewsEvent[];
  currentEvent: NewsEvent | null;
  
  // Game state
  difficulty: Difficulty;
  gameOver: boolean;
  gameOverReason: string | null;
  victory: boolean;
  
  // Special
  viewingPakistan: boolean;
  lastEmergencyRelease: number; // month when last used
  nuclearDrillsThisDecade: number;
  showNuclearFlash: boolean;
  screenShake: boolean;
}

// Difficulty settings
const DIFFICULTY_SETTINGS: Record<Difficulty, {
  budget: number;
  nuclearTimer: number;
  timerDecay: number;
  waterStressMultiplier: number;
  tensionMultiplier: number;
  pakistanStartTension: number;
  debtPercent: number;
}> = {
  nobel: {
    budget: 120,
    nuclearTimer: 180,
    timerDecay: 0.3,
    waterStressMultiplier: 0.85,
    tensionMultiplier: 0.8,
    pakistanStartTension: 70,
    debtPercent: 45
  },
  realistic: {
    budget: 87,
    nuclearTimer: 90,
    timerDecay: 0.5,
    waterStressMultiplier: 1.0,
    tensionMultiplier: 1.0,
    pakistanStartTension: 82,
    debtPercent: 78
  },
  hard: {
    budget: 68,
    nuclearTimer: 75,
    timerDecay: 0.7,
    waterStressMultiplier: 1.1,
    tensionMultiplier: 1.15,
    pakistanStartTension: 88,
    debtPercent: 95
  },
  brutal: {
    budget: 52,
    nuclearTimer: 45,
    timerDecay: 0.9,
    waterStressMultiplier: 1.2,
    tensionMultiplier: 1.3,
    pakistanStartTension: 92,
    debtPercent: 108
  },
  nightmare: {
    budget: 38,
    nuclearTimer: 35,
    timerDecay: 1.1,
    waterStressMultiplier: 1.35,
    tensionMultiplier: 1.45,
    pakistanStartTension: 95,
    debtPercent: 115
  },
  hell: {
    budget: 25,
    nuclearTimer: 25,
    timerDecay: 1.4,
    waterStressMultiplier: 1.5,
    tensionMultiplier: 1.6,
    pakistanStartTension: 98,
    debtPercent: 117
  }
};

// Initial regions data
const createInitialRegions = (difficulty: Difficulty): IndiaRegion[] => {
  const mult = DIFFICULTY_SETTINGS[difficulty].waterStressMultiplier;
  const tensionMult = DIFFICULTY_SETTINGS[difficulty].tensionMultiplier;
  
  return [
    {
      id: 'punjab',
      name: 'Punjab',
      nameRu: 'Пенджаб',
      waterStress: Math.min(99, Math.round(89 * mult)),
      socialTension: Math.min(99, Math.round(72 * tensionMult)),
      trustInGovernment: 48,
      militias: 0,
      population: 31,
      isCoastal: false,
      terrain: 'plains',
      description: 'Житница Индии, критически зависит от каналов Инда'
    },
    {
      id: 'haryana',
      name: 'Haryana',
      nameRu: 'Харьяна',
      waterStress: Math.min(99, Math.round(91 * mult)),
      socialTension: Math.min(99, Math.round(78 * tensionMult)),
      trustInGovernment: 42,
      militias: 0,
      population: 29,
      isCoastal: false,
      terrain: 'plains',
      description: 'Сельскохозяйственный центр, борется за воду с Пенджабом'
    },
    {
      id: 'rajasthan',
      name: 'Rajasthan',
      nameRu: 'Раджастхан',
      waterStress: Math.min(99, Math.round(94 * mult)),
      socialTension: Math.min(99, Math.round(82 * tensionMult)),
      trustInGovernment: 38,
      militias: 0,
      population: 81,
      isCoastal: false,
      terrain: 'desert',
      description: 'Пустыня Тар, минимальные водные ресурсы'
    },
    {
      id: 'gujarat',
      name: 'Gujarat',
      nameRu: 'Гуджарат',
      waterStress: Math.min(99, Math.round(76 * mult)),
      socialTension: Math.min(99, Math.round(54 * tensionMult)),
      trustInGovernment: 68,
      militias: 0,
      population: 71,
      isCoastal: true,
      terrain: 'coastal',
      description: 'Побережье Аравийского моря, потенциал для десалинизации'
    },
    {
      id: 'maharashtra',
      name: 'Maharashtra',
      nameRu: 'Махараштра',
      waterStress: Math.min(99, Math.round(68 * mult)),
      socialTension: Math.min(99, Math.round(46 * tensionMult)),
      trustInGovernment: 74,
      militias: 0,
      population: 126,
      isCoastal: true,
      terrain: 'coastal',
      description: 'Мумбаи и западное побережье, экономический центр'
    },
    {
      id: 'uttar-pradesh',
      name: 'Uttar Pradesh',
      nameRu: 'Уттар-Прадеш',
      waterStress: Math.min(99, Math.round(72 * mult)),
      socialTension: Math.min(99, Math.round(62 * tensionMult)),
      trustInGovernment: 58,
      militias: 0,
      population: 241,
      isCoastal: false,
      terrain: 'plains',
      description: 'Самый населённый штат, бассейн Ганга'
    },
    {
      id: 'jammu-kashmir',
      name: 'Jammu & Kashmir',
      nameRu: 'Джамму и Кашмир',
      waterStress: Math.min(99, Math.round(54 * mult)),
      socialTension: Math.min(99, Math.round(88 * tensionMult)),
      trustInGovernment: 22,
      militias: difficulty === 'hell' ? 3 : difficulty === 'nightmare' ? 2 : 1,
      population: 14,
      isCoastal: false,
      terrain: 'mountains',
      description: 'Спорная территория, источник рек, постоянный конфликт'
    },
    {
      id: 'himachal',
      name: 'Himachal Pradesh',
      nameRu: 'Химачал-Прадеш',
      waterStress: Math.min(99, Math.round(48 * mult)),
      socialTension: Math.min(99, Math.round(42 * tensionMult)),
      trustInGovernment: 76,
      militias: 0,
      population: 7,
      isCoastal: false,
      terrain: 'mountains',
      description: 'Гималаи, ледники, истоки рек'
    },
    {
      id: 'madhya-pradesh',
      name: 'Madhya Pradesh',
      nameRu: 'Мадхья-Прадеш',
      waterStress: Math.min(99, Math.round(71 * mult)),
      socialTension: Math.min(99, Math.round(58 * tensionMult)),
      trustInGovernment: 64,
      militias: 0,
      population: 85,
      isCoastal: false,
      terrain: 'plains',
      description: 'Центральная Индия, смешанное земледелие'
    },
    {
      id: 'telangana',
      name: 'Telangana',
      nameRu: 'Телангана',
      waterStress: Math.min(99, Math.round(74 * mult)),
      socialTension: Math.min(99, Math.round(66 * tensionMult)),
      trustInGovernment: 56,
      militias: 0,
      population: 38,
      isCoastal: false,
      terrain: 'plains',
      description: 'Хайдерабад, IT-центр, водные конфликты с соседями'
    },
    {
      id: 'andhra-pradesh',
      name: 'Andhra Pradesh',
      nameRu: 'Андхра-Прадеш',
      waterStress: Math.min(99, Math.round(79 * mult)),
      socialTension: Math.min(99, Math.round(70 * tensionMult)),
      trustInGovernment: 52,
      militias: 0,
      population: 54,
      isCoastal: true,
      terrain: 'coastal',
      description: 'Восточное побережье, дельта Кришны и Годавари'
    },
    {
      id: 'karnataka',
      name: 'Karnataka',
      nameRu: 'Карнатака',
      waterStress: Math.min(99, Math.round(77 * mult)),
      socialTension: Math.min(99, Math.round(68 * tensionMult)),
      trustInGovernment: 54,
      militias: 0,
      population: 68,
      isCoastal: true,
      terrain: 'coastal',
      description: 'Бенгалуру, конфликт с Тамилнадом за Кавери'
    },
    {
      id: 'sindh-india',
      name: 'Kutch (Sindh border)',
      nameRu: 'Кач (граница с Синдом)',
      waterStress: Math.min(99, Math.round(93 * mult)),
      socialTension: Math.min(99, Math.round(84 * tensionMult)),
      trustInGovernment: 34,
      militias: 0,
      population: 2,
      isCoastal: true,
      terrain: 'desert',
      description: 'Солончаки Ранн-оф-Кач, граница с Пакистаном'
    },
    {
      id: 'west-bengal',
      name: 'West Bengal',
      nameRu: 'Западная Бенгалия',
      waterStress: Math.min(99, Math.round(65 * mult)),
      socialTension: Math.min(99, Math.round(50 * tensionMult)),
      trustInGovernment: 70,
      militias: 0,
      population: 100,
      isCoastal: true,
      terrain: 'coastal',
      description: 'Дельта Ганга, Калькутта, муссонные наводнения'
    },
    {
      id: 'bihar',
      name: 'Bihar',
      nameRu: 'Бихар',
      waterStress: Math.min(99, Math.round(80 * mult)),
      socialTension: Math.min(99, Math.round(74 * tensionMult)),
      trustInGovernment: 48,
      militias: 0,
      population: 128,
      isCoastal: false,
      terrain: 'plains',
      description: 'Равнины Ганга, наводнения и засухи'
    }
  ];
};

// Rivers data
const createInitialRivers = (): RiverState[] => [
  {
    id: 'beas',
    name: 'Beas',
    nameRu: 'Беас',
    isClosed: false,
    waterVolume: 8,
    timerPenalty: 20
  },
  {
    id: 'ravi',
    name: 'Ravi',
    nameRu: 'Рави',
    isClosed: false,
    waterVolume: 12,
    timerPenalty: 25
  },
  {
    id: 'sutlej',
    name: 'Sutlej',
    nameRu: 'Сатледж',
    isClosed: false,
    waterVolume: 15,
    timerPenalty: 30
  }
];

// All initiatives
const createInitiatives = (): IndiaInitiative[] => [
  // UNIQUE INDIA INITIATIVES
  {
    id: 'close-beas',
    name: 'Close Beas River',
    nameRu: 'Перекрытие реки Беас',
    description: 'Completely stop water flow to Pakistan via Beas',
    descriptionRu: 'Полностью прекратить подачу воды в Пакистан через Беас',
    category: 'unique',
    cost: 0,
    duration: 0,
    effects: {
      pakistanWaterLoss: 8,
      nuclearTimer: -20
    },
    hiddenEffectsRu: 'ВНИМАНИЕ: −20 дней ядерного таймера!',
    isUnique: true
  },
  {
    id: 'close-ravi',
    name: 'Close Ravi River',
    nameRu: 'Перекрытие реки Рави',
    description: 'Completely stop water flow to Pakistan via Ravi',
    descriptionRu: 'Полностью прекратить подачу воды в Пакистан через Рави',
    category: 'unique',
    cost: 0,
    duration: 0,
    effects: {
      pakistanWaterLoss: 12,
      nuclearTimer: -25
    },
    hiddenEffectsRu: 'ВНИМАНИЕ: −25 дней ядерного таймера!',
    isUnique: true
  },
  {
    id: 'close-sutlej',
    name: 'Close Sutlej River',
    nameRu: 'Перекрытие реки Сатледж',
    description: 'Completely stop water flow to Pakistan via Sutlej',
    descriptionRu: 'Полностью прекратить подачу воды в Пакистан через Сатледж',
    category: 'unique',
    cost: 0,
    duration: 0,
    effects: {
      pakistanWaterLoss: 15,
      nuclearTimer: -30
    },
    hiddenEffectsRu: 'ВНИМАНИЕ: −30 дней ядерного таймера!',
    isUnique: true
  },
  {
    id: 'operation-sindh-tao',
    name: 'Operation Sindh Tao',
    nameRu: 'Операция «Синдх Тао»',
    description: 'Complete blockade of main Indus for 120 days',
    descriptionRu: 'Полное перекрытие основного Инда на 120 дней',
    category: 'unique',
    cost: 4,
    duration: 0,
    effects: {
      pakistanWaterLoss: 42,
      nuclearTimer: -70
    },
    hiddenEffectsRu: 'КАТАСТРОФА: Таймер мгновенно −70 дней! Пакистан потеряет 42 млрд м³!',
    isUnique: true
  },
  {
    id: 'emergency-release',
    name: 'Emergency Water Release',
    nameRu: 'Аварийный спуск воды',
    description: 'Release emergency water to Pakistan (once per 5 years)',
    descriptionRu: 'Экстренный спуск воды в Пакистан (раз в 5 лет)',
    category: 'unique',
    cost: 2,
    duration: 0,
    effects: {
      nuclearTimer: 45,
      internationalPressure: -30,
      budget: -2
    },
    hiddenEffectsRu: '+45 дней таймера, −30 международного давления',
    requirements: {
      cooldown: 60 // 5 years
    },
    isUnique: true,
    cooldown: 0
  },
  {
    id: 'kalabagh-dam',
    name: 'Fund Kalabagh Dam (Secret)',
    nameRu: 'Финансировать плотину Калабаг (тайно)',
    description: 'Secretly fund controversial dam inside Pakistan',
    descriptionRu: 'Тайно профинансировать спорную плотину внутри Пакистана',
    category: 'unique',
    cost: 9,
    duration: 48,
    effects: {
      pakistanTension: 60
    },
    hiddenEffectsRu: 'Провоцирует гражданскую войну в Пакистане. +20 млрд м³ Индии навсегда после постройки.',
    isUnique: true
  },
  
  // CIVIL INITIATIVES (same as other campaigns)
  {
    id: 'drip-irrigation-1',
    name: 'Drip Irrigation Level 1',
    nameRu: 'Капельное орошение уровня 1',
    description: 'Basic drip irrigation in selected region',
    descriptionRu: 'Базовая система капельного орошения в выбранном регионе',
    category: 'civil',
    cost: 0.18,
    duration: 18,
    effects: {
      waterStress: -12
    },
    hiddenEffectsRu: '+4% социального напряжения первые 2 года (фермеры ненавидят менять привычки)'
  },
  {
    id: 'drip-irrigation-2',
    name: 'Drip Irrigation Level 2 (Israeli Standard)',
    nameRu: 'Капельное орошение уровня 2 (Израильский стандарт)',
    description: 'Advanced Israeli-standard drip irrigation',
    descriptionRu: 'Продвинутая израильская система капельного орошения',
    category: 'civil',
    cost: 1.2,
    duration: 36,
    effects: {
      waterStress: -28
    },
    hiddenEffectsRu: '−8 доверия к власти в регионе (слишком дорого и «для богатых фермеров»)',
    requirements: {
      minBudget: 1.2
    }
  },
  {
    id: 'canal-lining',
    name: 'Canal Concrete Lining',
    nameRu: 'Облицовка каналов бетоном',
    description: 'Line major canals with concrete to reduce losses',
    descriptionRu: 'Облицовка главных каналов бетоном для снижения потерь',
    category: 'civil',
    cost: 0.85,
    duration: 48,
    effects: {
      waterStress: -22
    },
    hiddenEffectsRu: '+15 социального напряжения в нижних регионах'
  },
  {
    id: 'desalination-small',
    name: 'Small Desalination Plants (10 units)',
    nameRu: 'Малые опреснительные установки (10 шт.)',
    description: 'Build 10 small desalination plants in coastal region',
    descriptionRu: 'Построить 10 малых опреснительных установок в прибрежном регионе',
    category: 'civil',
    cost: 1.1,
    duration: 30,
    effects: {
      waterStress: -15
    },
    hiddenEffectsRu: '+450 млн $/год эксплуатация'
  },
  {
    id: 'desalination-large',
    name: 'Large Desalination Complex',
    nameRu: 'Крупный опреснительный комплекс',
    description: 'Build Saudi-scale desalination complex',
    descriptionRu: 'Построить опреснительный комплекс масштаба Саудовской Аравии',
    category: 'civil',
    cost: 11,
    duration: 84,
    effects: {
      waterStress: -35
    },
    hiddenEffectsRu: '+2.2 млрд $/год эксплуатация, +20 международного давления'
  },
  {
    id: 'virtual-water',
    name: 'Virtual Water Import',
    nameRu: 'Импорт виртуальной воды',
    description: 'Import grain instead of growing it (annual subscription)',
    descriptionRu: 'Импорт зерна вместо выращивания (ежегодная подписка)',
    category: 'civil',
    cost: 0.6,
    duration: 0,
    effects: {
      waterStress: -15,
      internationalPressure: 8
    },
    hiddenEffectsRu: '+8 международного давления (обвинения в «непатриотичности»)'
  },
  {
    id: 'population-relocation',
    name: 'Population Relocation',
    nameRu: 'Переселение населения',
    description: 'Relocate population from critical water zones',
    descriptionRu: 'Переселение населения из критических водных зон',
    category: 'civil',
    cost: 3.4,
    duration: 72,
    effects: {
      waterStress: -40,
      trust: -35,
      socialTension: 30
    },
    hiddenEffectsRu: '−35 доверия по всей стране, +30 напряжения в принимающих регионах'
  },
  {
    id: 'wetland-restoration',
    name: 'Wetland Restoration',
    nameRu: 'Восстановление водно-болотных угодий',
    description: 'Restore wetlands for natural water filtration',
    descriptionRu: 'Восстановление болотных угодий для естественной фильтрации',
    category: 'civil',
    cost: 0.42,
    duration: 60,
    effects: {
      waterStress: -8
    },
    hiddenEffectsRu: '−12% дохода от сельского хозяйства в регионе первые 5 лет'
  },
  
  // DIPLOMATIC INITIATIVES
  {
    id: 'joint-monitoring-1',
    name: 'Joint Water Monitoring Level 1',
    nameRu: 'Совместный мониторинг стока уровня 1',
    description: 'Establish basic joint monitoring with Pakistan',
    descriptionRu: 'Базовый совместный мониторинг с Пакистаном',
    category: 'diplomatic',
    cost: 0.08,
    duration: 12,
    effects: {
      nuclearTimer: 15,
      internationalPressure: -10
    },
    hiddenEffectsRu: 'Если доверие упадёт ниже 0 — они перестанут делиться данными'
  },
  {
    id: 'joint-monitoring-4',
    name: 'Full Transparency Agreement',
    nameRu: 'Полная прозрачность (мониторинг ур. 4)',
    description: 'Complete water data sharing with Pakistan',
    descriptionRu: 'Полный обмен водными данными с Пакистаном',
    category: 'diplomatic',
    cost: 1.2,
    duration: 60,
    effects: {
      nuclearTimer: 45,
      internationalPressure: -30
    },
    hiddenEffectsRu: 'Ты тоже обязан показывать все свои данные'
  },
  {
    id: 'ecosystem-payments',
    name: 'Ecosystem Service Payments',
    nameRu: 'Платежи за экосистемные услуги',
    description: 'Pay Pakistan for upstream water services',
    descriptionRu: 'Платить Пакистану за экосистемные услуги верховья',
    category: 'diplomatic',
    cost: 0.5,
    duration: 0,
    effects: {
      nuclearTimer: 20,
      budget: -0.5
    },
    hiddenEffectsRu: 'Если прекратить платежи — −50 доверия мгновенно'
  },
  {
    id: 'secret-negotiations',
    name: 'Secret Back-Channel Negotiations',
    nameRu: 'Секретные переговоры',
    description: 'Secret diplomatic channel with Islamabad',
    descriptionRu: 'Тайный дипломатический канал с Исламабадом',
    category: 'diplomatic',
    cost: 0.3,
    duration: 6,
    effects: {
      nuclearTimer: 30
    },
    hiddenEffectsRu: '70% шанс утечки в прессу → +40 международного давления'
  },
  {
    id: 'international-arbitration',
    name: 'International Arbitration (Hague)',
    nameRu: 'Международный арбитраж (Гаага)',
    description: 'Submit water dispute to international court',
    descriptionRu: 'Передать водный спор в международный суд',
    category: 'diplomatic',
    cost: 0.45,
    duration: 96,
    effects: {
      nuclearTimer: 60
    },
    hiddenEffectsRu: '50% шанс проиграть дело → −40 доверия навсегда'
  },
  
  // MILITARY INITIATIVES
  {
    id: 'infrastructure-guard-1',
    name: 'Infrastructure Guard Level 1',
    nameRu: 'Военизированная охрана инфраструктуры ур. 1',
    description: 'Basic military protection for dams and canals',
    descriptionRu: 'Базовая военная охрана плотин и каналов',
    category: 'military',
    cost: 0.4,
    duration: 6,
    effects: {
      socialTension: 15
    },
    hiddenEffectsRu: '−60% успеха терактов на плотинах'
  },
  {
    id: 'infrastructure-guard-3',
    name: 'Infrastructure Guard Level 3',
    nameRu: 'Военизированная охрана инфраструктуры ур. 3',
    description: 'Maximum military protection for all water infrastructure',
    descriptionRu: 'Максимальная военная охрана всей водной инфраструктуры',
    category: 'military',
    cost: 2.1,
    duration: 12,
    effects: {
      socialTension: 25
    },
    hiddenEffectsRu: '−90% успеха терактов, но страна выглядит как военная диктатура'
  },
  {
    id: 'emergency-state',
    name: 'State of Emergency in Region',
    nameRu: 'Чрезвычайное положение в регионе',
    description: 'Declare state of emergency in selected region',
    descriptionRu: 'Объявить чрезвычайное положение в выбранном регионе',
    category: 'military',
    cost: 0,
    duration: 0,
    effects: {
      socialTension: -40,
      trust: -50
    },
    hiddenEffectsRu: '−50 доверия к власти навсегда в этом регионе'
  },
  {
    id: 'cyber-attack',
    name: 'Cyber Attack on Pakistan Dams',
    nameRu: 'Кибератака на SCADA-систему Пакистана',
    description: 'Hack Pakistan dam control systems',
    descriptionRu: 'Взломать системы управления пакистанскими плотинами',
    category: 'military',
    cost: 0.8,
    duration: 3,
    effects: {
      nuclearTimer: -40
    },
    hiddenEffectsRu: '80% шанс быть пойманным → мгновенная война (таймер = 0)'
  },
  {
    id: 'sabotage',
    name: 'Sabotage Pakistan Infrastructure',
    nameRu: 'Саботаж инфраструктуры Пакистана',
    description: 'Covert operation to damage Pakistan water infrastructure',
    descriptionRu: 'Тайная операция по повреждению водной инфраструктуры Пакистана',
    category: 'military',
    cost: 1.5,
    duration: 6,
    effects: {
      pakistanTension: 40,
      nuclearTimer: -60
    },
    hiddenEffectsRu: '95% шанс начала полномасштабной войны'
  }
];

// Action types
type IndiaAction =
  | { type: 'TICK' }
  | { type: 'SET_SPEED'; payload: number }
  | { type: 'TOGGLE_PAUSE' }
  | { type: 'SELECT_REGION'; payload: string | null }
  | { type: 'TOGGLE_PAKISTAN_VIEW' }
  | { type: 'CLOSE_RIVER'; payload: string }
  | { type: 'OPEN_RIVER'; payload: string }
  | { type: 'ACTIVATE_INITIATIVE'; payload: { initiativeId: string; regionId?: string } }
  | { type: 'COMPLETE_INITIATIVE'; payload: string }
  | { type: 'SHOW_EVENT'; payload: NewsEvent }
  | { type: 'DISMISS_EVENT' }
  | { type: 'TRIGGER_NUCLEAR_FLASH' }
  | { type: 'END_NUCLEAR_FLASH' }
  | { type: 'SCREEN_SHAKE'; payload: boolean }
  | { type: 'SET_GAME_OVER'; payload: { reason: string; victory: boolean } };

// Reducer
function indiaGameReducer(state: IndiaGameState, action: IndiaAction): IndiaGameState {
  switch (action.type) {
    case 'TICK': {
      if (state.gameOver || state.isPaused) return state;
      
      let newMonth = state.month + 1;
      let newYear = state.year;
      let newTotalMonths = state.totalMonths + 1;
      
      if (newMonth > 12) {
        newMonth = 1;
        newYear += 1;
      }
      
      // Nuclear timer decay
      let newTimer = state.nuclearTimer - state.timerDecayRate;
      
      // Pakistan stress affects timer
      if (state.pakistan.waterStress > 97) {
        newTimer -= 2; // Accelerated decay when Pakistan is dying
      } else if (state.pakistan.waterStress > 94) {
        newTimer -= 1;
      }
      
      // Check for nuclear war
      if (newTimer <= 0) {
        return {
          ...state,
          nuclearTimer: 0,
          showNuclearFlash: true,
          gameOver: true,
          gameOverReason: 'Nuclear exchange initiated. 2045 never came.',
          victory: false
        };
      }
      
      // Update regions
      const updatedRegions = state.regions.map(region => {
        let waterStress = region.waterStress;
        let socialTension = region.socialTension;
        let trust = region.trustInGovernment;
        let militias = region.militias;
        
        // Natural water stress increase
        waterStress += 0.1 + Math.random() * 0.2;
        
        // Monsoon season (June-September) - slight relief
        if (newMonth >= 6 && newMonth <= 9) {
          waterStress -= 0.3;
        }
        
        // Summer (April-June) - worse
        if (newMonth >= 4 && newMonth <= 6) {
          waterStress += 0.2;
        }
        
        // Social tension based on water stress
        if (waterStress > 90) {
          socialTension += 0.5;
        } else if (waterStress > 80) {
          socialTension += 0.2;
        }
        
        // Trust decay when things are bad
        if (socialTension > 80) {
          trust -= 0.3;
        }
        
        // Militia spawn
        if (socialTension >= 95 && Math.random() < 0.1) {
          militias += 1;
        }
        
        return {
          ...region,
          waterStress: Math.min(99, Math.max(0, waterStress)),
          socialTension: Math.min(99, Math.max(0, socialTension)),
          trustInGovernment: Math.min(100, Math.max(0, trust)),
          militias
        };
      });
      
      // Update Pakistan
      let pakistanStress = state.pakistan.waterStress;
      let pakistanTension = state.pakistan.socialTension;
      let pakistanPop = state.pakistan.population;
      
      // Rivers affect Pakistan
      const closedRivers = state.rivers.filter(r => r.isClosed);
      const waterLost = closedRivers.reduce((sum, r) => sum + r.waterVolume, 0);
      
      if (waterLost > 0) {
        pakistanStress += waterLost * 0.05;
        pakistanTension += waterLost * 0.1;
      }
      
      // Natural growth
      pakistanStress += 0.1;
      pakistanTension += 0.05;
      
      // Population growth (to 410 million by 2045)
      if (newMonth === 1) {
        pakistanPop += 4; // ~4 million per year
      }
      
      // Check if Pakistan triggers nuclear
      if (pakistanStress > 97 && pakistanTension > 90) {
        newTimer -= 5; // Rapid decay
      }
      
      // Process active initiatives
      const updatedActiveInitiatives = state.activeInitiatives
        .map(init => ({
          ...init,
          monthsRemaining: (init.monthsRemaining || 0) - 1
        }))
        .filter(init => (init.monthsRemaining || 0) > 0);
      
      // Update initiative cooldowns
      const updatedInitiatives = state.initiatives.map(init => ({
        ...init,
        cooldown: init.cooldown ? Math.max(0, init.cooldown - 1) : 0
      }));
      
      // Check victory condition
      let victory: boolean = false;
      let gameOver: boolean = state.gameOver;
      let gameOverReason: string | null = state.gameOverReason;
      
      if (newYear >= 2045 && newMonth >= 12) {
        if (newTimer > 0) {
          victory = true;
          gameOver = true;
          gameOverReason = 'victory';
        }
      }
      
      // Check defeat conditions
      const avgWaterStress = updatedRegions.reduce((sum, r) => sum + r.waterStress, 0) / updatedRegions.length;
      const totalMilitias = updatedRegions.reduce((sum, r) => sum + r.militias, 0);
      
      if (avgWaterStress >= 95 && totalMilitias >= 5) {
        gameOver = true;
        gameOverReason = 'India collapsed into civil war. Water ran out.';
        victory = false;
      }
      
      return {
        ...state,
        month: newMonth,
        year: newYear,
        totalMonths: newTotalMonths,
        nuclearTimer: Math.max(0, newTimer),
        regions: updatedRegions,
        pakistan: {
          ...state.pakistan,
          waterStress: Math.min(99, pakistanStress),
          socialTension: Math.min(99, pakistanTension),
          population: Math.min(410, pakistanPop)
        },
        activeInitiatives: updatedActiveInitiatives,
        initiatives: updatedInitiatives,
        gameOver,
        gameOverReason,
        victory
      };
    }
    
    case 'SET_SPEED':
      return { ...state, gameSpeed: action.payload, isPaused: action.payload === 0 };
    
    case 'TOGGLE_PAUSE':
      return { ...state, isPaused: !state.isPaused };
    
    case 'SELECT_REGION':
      return { ...state, selectedRegion: action.payload };
    
    case 'TOGGLE_PAKISTAN_VIEW':
      return { ...state, viewingPakistan: !state.viewingPakistan };
    
    case 'CLOSE_RIVER': {
      const river = state.rivers.find(r => r.id === action.payload);
      if (!river || river.isClosed) return state;
      
      return {
        ...state,
        rivers: state.rivers.map(r => 
          r.id === action.payload ? { ...r, isClosed: true } : r
        ),
        nuclearTimer: Math.max(0, state.nuclearTimer - river.timerPenalty),
        pakistan: {
          ...state.pakistan,
          waterStress: Math.min(99, state.pakistan.waterStress + river.waterVolume * 0.5),
          socialTension: Math.min(99, state.pakistan.socialTension + river.waterVolume * 0.8),
          waterReceived: state.pakistan.waterReceived - river.waterVolume
        }
      };
    }
    
    case 'OPEN_RIVER': {
      const river = state.rivers.find(r => r.id === action.payload);
      if (!river || !river.isClosed) return state;
      
      return {
        ...state,
        rivers: state.rivers.map(r => 
          r.id === action.payload ? { ...r, isClosed: false } : r
        ),
        nuclearTimer: Math.min(180, state.nuclearTimer + 10), // Small bonus for reopening
        pakistan: {
          ...state.pakistan,
          waterReceived: state.pakistan.waterReceived + river.waterVolume
        }
      };
    }
    
    case 'ACTIVATE_INITIATIVE': {
      const initiative = state.initiatives.find(i => i.id === action.payload.initiativeId);
      if (!initiative) return state;
      
      // Check cooldown
      if (initiative.cooldown && initiative.cooldown > 0) return state;
      
      // Check budget
      if (initiative.cost > state.budget) return state;
      
      let newState = { ...state };
      newState.budget -= initiative.cost;
      
      // Apply immediate effects
      if (initiative.effects.nuclearTimer) {
        newState.nuclearTimer = Math.max(0, Math.min(180, newState.nuclearTimer + initiative.effects.nuclearTimer));
      }
      
      if (initiative.effects.internationalPressure) {
        newState.internationalPressure = Math.max(0, Math.min(100, newState.internationalPressure + initiative.effects.internationalPressure));
      }
      
      if (initiative.effects.pakistanTension) {
        newState.pakistan = {
          ...newState.pakistan,
          socialTension: Math.min(99, newState.pakistan.socialTension + initiative.effects.pakistanTension)
        };
      }
      
      if (initiative.effects.pakistanWaterLoss) {
        newState.pakistan = {
          ...newState.pakistan,
          waterStress: Math.min(99, newState.pakistan.waterStress + initiative.effects.pakistanWaterLoss * 0.5),
          waterReceived: newState.pakistan.waterReceived - initiative.effects.pakistanWaterLoss
        };
      }
      
      // Apply region effects
      if (action.payload.regionId && (initiative.effects.waterStress || initiative.effects.socialTension || initiative.effects.trust)) {
        newState.regions = newState.regions.map(region => {
          if (region.id !== action.payload.regionId) return region;
          
          return {
            ...region,
            waterStress: Math.max(0, Math.min(99, region.waterStress + (initiative.effects.waterStress || 0))),
            socialTension: Math.max(0, Math.min(99, region.socialTension + (initiative.effects.socialTension || 0))),
            trustInGovernment: Math.max(0, Math.min(100, region.trustInGovernment + (initiative.effects.trust || 0)))
          };
        });
      }
      
      // Set cooldown for emergency release
      if (initiative.id === 'emergency-release') {
        newState.initiatives = newState.initiatives.map(i =>
          i.id === 'emergency-release' ? { ...i, cooldown: 60 } : i
        );
        newState.lastEmergencyRelease = state.totalMonths;
      }
      
      // Add to active if has duration
      if (initiative.duration > 0) {
        newState.activeInitiatives = [
          ...newState.activeInitiatives,
          { ...initiative, monthsRemaining: initiative.duration, targetRegion: action.payload.regionId }
        ];
      }
      
      return newState;
    }
    
    case 'COMPLETE_INITIATIVE': {
      return {
        ...state,
        activeInitiatives: state.activeInitiatives.filter(i => i.id !== action.payload)
      };
    }
    
    case 'SHOW_EVENT':
      return { ...state, currentEvent: action.payload };
    
    case 'DISMISS_EVENT':
      return { ...state, currentEvent: null };
    
    case 'TRIGGER_NUCLEAR_FLASH':
      return { ...state, showNuclearFlash: true };
    
    case 'END_NUCLEAR_FLASH':
      return { ...state, showNuclearFlash: false };
    
    case 'SCREEN_SHAKE':
      return { ...state, screenShake: action.payload };
    
    case 'SET_GAME_OVER':
      return {
        ...state,
        gameOver: true,
        gameOverReason: action.payload.reason,
        victory: action.payload.victory
      };
    
    default:
      return state;
  }
}

// Create initial state
function createInitialState(difficulty: Difficulty): IndiaGameState {
  const settings = DIFFICULTY_SETTINGS[difficulty];
  
  const initialState: IndiaGameState = {
    year: 2025,
    month: 8,
    totalMonths: 0,
    gameSpeed: 2,
    isPaused: false,
    
    budget: settings.budget,
    internationalPressure: 45,
    nuclearTimer: settings.nuclearTimer,
    timerDecayRate: settings.timerDecay,
    
    regions: createInitialRegions(difficulty),
    selectedRegion: null,
    
    pakistan: {
      waterStress: settings.pakistanStartTension,
      socialTension: settings.pakistanStartTension * 0.9,
      population: 240,
      waterReceived: 145,
      civilWarActive: false
    },
    
    rivers: createInitialRivers(),
    
    initiatives: createInitiatives(),
    activeInitiatives: [],
    
    events: [],
    currentEvent: null,
    
    difficulty,
    gameOver: false,
    gameOverReason: null,
    victory: false,
    
    viewingPakistan: false,
    lastEmergencyRelease: -60,
    nuclearDrillsThisDecade: 0,
    showNuclearFlash: false,
    screenShake: false
  };
  
  return initialState;
}

// Context
interface IndiaGameContextType {
  state: IndiaGameState;
  dispatch: React.Dispatch<IndiaAction>;
  closeRiver: (riverId: string) => void;
  openRiver: (riverId: string) => void;
  activateInitiative: (initiativeId: string, regionId?: string) => void;
  selectRegion: (regionId: string | null) => void;
  togglePakistanView: () => void;
  setSpeed: (speed: number) => void;
  togglePause: () => void;
}

const IndiaGameContext = createContext<IndiaGameContextType | null>(null);

export function IndiaGameProvider({ 
  children, 
  difficulty = 'realistic' 
}: { 
  children: React.ReactNode;
  difficulty?: Difficulty;
}) {
  const [state, dispatch] = useReducer(indiaGameReducer, createInitialState(difficulty));
  const gameLoopRef = useRef<NodeJS.Timeout | null>(null);
  
  // Game loop
  useEffect(() => {
    if (state.isPaused || state.gameOver) {
      if (gameLoopRef.current) {
        clearInterval(gameLoopRef.current);
        gameLoopRef.current = null;
      }
      return;
    }
    
    const speeds = [0, 4000, 2000, 800];
    const interval = speeds[state.gameSpeed] || 2000;
    
    gameLoopRef.current = setInterval(() => {
      dispatch({ type: 'TICK' });
    }, interval);
    
    return () => {
      if (gameLoopRef.current) {
        clearInterval(gameLoopRef.current);
      }
    };
  }, [state.gameSpeed, state.isPaused, state.gameOver]);
  
  // Random events (nuclear drills every ~3 years)
  useEffect(() => {
    if (state.totalMonths > 0 && state.totalMonths % 36 === 0 && !state.gameOver) {
      dispatch({ type: 'SCREEN_SHAKE', payload: true });
      setTimeout(() => {
        dispatch({ type: 'SCREEN_SHAKE', payload: false });
      }, 3000);
      
      dispatch({
        type: 'SHOW_EVENT',
        payload: {
          id: `drill-${state.totalMonths}`,
          month: state.month,
          year: state.year,
          title: 'Pakistan Conducts Nuclear Drills',
          titleRu: 'Пакистан проводит ядерные учения',
          description: 'Pakistani military conducted nuclear readiness exercises near the border.',
          descriptionRu: 'Пакистанские военные провели учения по ядерной готовности вблизи границы.',
          type: 'crisis'
        }
      });
    }
  }, [state.totalMonths, state.gameOver, state.month, state.year]);
  
  const closeRiver = useCallback((riverId: string) => {
    dispatch({ type: 'CLOSE_RIVER', payload: riverId });
  }, []);
  
  const openRiver = useCallback((riverId: string) => {
    dispatch({ type: 'OPEN_RIVER', payload: riverId });
  }, []);
  
  const activateInitiative = useCallback((initiativeId: string, regionId?: string) => {
    dispatch({ type: 'ACTIVATE_INITIATIVE', payload: { initiativeId, regionId } });
  }, []);
  
  const selectRegion = useCallback((regionId: string | null) => {
    dispatch({ type: 'SELECT_REGION', payload: regionId });
  }, []);
  
  const togglePakistanView = useCallback(() => {
    dispatch({ type: 'TOGGLE_PAKISTAN_VIEW' });
  }, []);
  
  const setSpeed = useCallback((speed: number) => {
    dispatch({ type: 'SET_SPEED', payload: speed });
  }, []);
  
  const togglePause = useCallback(() => {
    dispatch({ type: 'TOGGLE_PAUSE' });
  }, []);
  
  return (
    <IndiaGameContext.Provider value={{
      state,
      dispatch,
      closeRiver,
      openRiver,
      activateInitiative,
      selectRegion,
      togglePakistanView,
      setSpeed,
      togglePause
    }}>
      {children}
    </IndiaGameContext.Provider>
  );
}

export function useIndiaGame() {
  const context = useContext(IndiaGameContext);
  if (!context) {
    throw new Error('useIndiaGame must be used within IndiaGameProvider');
  }
  return context;
}
